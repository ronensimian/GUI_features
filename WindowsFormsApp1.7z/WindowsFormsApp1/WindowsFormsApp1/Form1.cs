﻿using System;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        
        SerialPort sp;



        public Form1()
        {
            InitializeComponent();
   

            // Initialize screen displays
            Screen[] ScreenArray = Screen.AllScreens;
            comboBox_Screen.Items.Clear();
            for (int i = 0; i < Screen.AllScreens.Length; i++)
            {
                comboBox_Screen.Items.Add("Display " + Convert.ToString(i+1));
            }
            if (comboBox_Screen.Items.Count > 0)
            {
                comboBox_Screen.SelectedIndex = 0;
            }

        }

       
        private void button_Connect_Click(object sender, EventArgs e)
        {
            if (button_Connect.Text == "Connect")
            {
                button_Connect.Text = "Disconnect";
                comboBox_ComPortsList.Enabled = false;
                button_Send.Enabled = true;
                button_LED.Enabled = true;

                sp = new SerialPort(comboBox_ComPortsList.SelectedItem.ToString(), 115_200, Parity.None, 8, StopBits.One);
                sp.Open();
                sp.ReadExisting();  // clear buffer's previous data
                sp.DataReceived += new SerialDataReceivedEventHandler(Receive);
            }
            else
            {
                button_Connect.Text = "Connect";
                comboBox_ComPortsList.Enabled = true;
                button_Send.Enabled = false;
                button_LED.Enabled = false;
                if (sp.IsOpen) sp.Close();
            }
        }

        private void Receive(object sender, SerialDataReceivedEventArgs e)
        {
            if (sp != null)
            {
                if (sp.IsOpen)
                {
                    Thread.Sleep(100);
                    this.Invoke((MethodInvoker)delegate
                    {
                        textBox_Rx.Text = sp.ReadExisting() + textBox_Rx.Text;  // textBox - pushing old data down
                        #region scroll Down Automatically
                        /*
                        textBox_Rx.Text += sp.ReadExisting();
                        textBox_Rx.SelectionStart = textBox_Rx.TextLength;
                        textBox_Rx.ScrollToCaret();
                        */
                        #endregion scroll Down Automatically
                        dataGridView_Rx.Rows.Add(textBox_Rx.Lines[0], textBox_Rx.Lines[0].Length, IsValid(textBox_Rx.Lines[0]));  // gridView - new data to bottom line
                        dataGridView_Rx.Columns.Add("kookoo", "kaka");
                    });
                }
            }
        }
        // TODO something. Shows TODO's in Task List

        private bool IsValid(string msg)  // comparing to an hex number
        {
            bool isValid;
            int msgAsNum = Convert.ToInt32(msg);
            if (msgAsNum == 0x00)
            {
                isValid = true;
            }
            else
            {
                isValid = false;
            }
            return isValid;
        }


        private void comboBox_ComPortsList_DropDown(object sender, EventArgs e)
        {
            comboBox_ComPortsList.Items.Clear();
            comboBox_ComPortsList.Items.AddRange(SerialPort.GetPortNames());
        }

        private void button_Send_Click(object sender, EventArgs e)
        {
            if (sp.IsOpen)
            {
                sp.Write(textBox_Tx.Text);
            }
        }
        
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (sp != null) if (sp.IsOpen) sp.Close();
        }

        private void button_LED_Click(object sender, EventArgs e)
        {
            byte[] myArray = new byte[3];
            myArray[0] = 0xA5;  // header
            myArray[2] = 0xBF;  // footer

            string str;
            if (button_LED.Text == "LED ON")
            {
                button_LED.Text = "LED OFF";
                myArray[1] = 0x01;

                sp.ReadExisting();  // clear buffer's previous data
                sp.Write(myArray, 0, 3);
            }
            else
            {
                button_LED.Text = "LED ON";
                myArray[1] = 0x00;
                sp.Write(myArray, 0, 3);
                str = sp.ReadExisting();
            }
        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            numericUpDown_Number.Value--;
            if (numericUpDown_Number.Value == 0)
            {
                Application.Exit();
            }

            progressBarMarquee.Value++;
        }

        private void numericUpDown_Number_ValueChanged(object sender, EventArgs e)
        {
            progressBar.Minimum = Convert.ToInt32(numericUpDown_Number.Minimum);
            progressBar.Maximum = (int)numericUpDown_Number.Maximum;
            progressBar.Value = (int)numericUpDown_Number.Value;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button_color_Click(object sender, EventArgs e)
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                //panel1.BackColor = colorDialog.Color;
                button_color.BackColor = colorDialog.Color;
            }
        }
    }
}
