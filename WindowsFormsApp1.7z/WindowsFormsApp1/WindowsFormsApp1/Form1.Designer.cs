﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_Send = new System.Windows.Forms.Button();
            this.textBox_Rx = new System.Windows.Forms.TextBox();
            this.button_Connect = new System.Windows.Forms.Button();
            this.comboBox_ComPortsList = new System.Windows.Forms.ComboBox();
            this.label_ComPort = new System.Windows.Forms.Label();
            this.label_Tx = new System.Windows.Forms.Label();
            this.label_Rx = new System.Windows.Forms.Label();
            this.label_RxGrid = new System.Windows.Forms.Label();
            this.dataGridView_Rx = new System.Windows.Forms.DataGridView();
            this.MSG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.length = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isValid = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.button_LED = new System.Windows.Forms.Button();
            this.textBox_Tx = new System.Windows.Forms.TextBox();
            this.button_Exit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Transparent = new System.Windows.Forms.Label();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.label_Timer = new System.Windows.Forms.Label();
            this.numericUpDown_Number = new System.Windows.Forms.NumericUpDown();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thing1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thing2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.button_color = new System.Windows.Forms.Button();
            this.comboBox_Screen = new System.Windows.Forms.ComboBox();
            this.label_Screen = new System.Windows.Forms.Label();
            this.progressBarMarquee = new System.Windows.Forms.ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Rx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Number)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_Send
            // 
            this.button_Send.Enabled = false;
            this.button_Send.Location = new System.Drawing.Point(191, 147);
            this.button_Send.Name = "button_Send";
            this.button_Send.Size = new System.Drawing.Size(75, 23);
            this.button_Send.TabIndex = 0;
            this.button_Send.Text = "Send";
            this.button_Send.UseVisualStyleBackColor = true;
            this.button_Send.Click += new System.EventHandler(this.button_Send_Click);
            // 
            // textBox_Rx
            // 
            this.textBox_Rx.Location = new System.Drawing.Point(347, 39);
            this.textBox_Rx.Multiline = true;
            this.textBox_Rx.Name = "textBox_Rx";
            this.textBox_Rx.ReadOnly = true;
            this.textBox_Rx.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_Rx.Size = new System.Drawing.Size(355, 131);
            this.textBox_Rx.TabIndex = 1;
            // 
            // button_Connect
            // 
            this.button_Connect.Location = new System.Drawing.Point(191, 37);
            this.button_Connect.Name = "button_Connect";
            this.button_Connect.Size = new System.Drawing.Size(75, 23);
            this.button_Connect.TabIndex = 0;
            this.button_Connect.Text = "Connect";
            this.button_Connect.UseVisualStyleBackColor = true;
            this.button_Connect.Click += new System.EventHandler(this.button_Connect_Click);
            // 
            // comboBox_ComPortsList
            // 
            this.comboBox_ComPortsList.BackColor = System.Drawing.SystemColors.Window;
            this.comboBox_ComPortsList.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.comboBox_ComPortsList.FormattingEnabled = true;
            this.comboBox_ComPortsList.Location = new System.Drawing.Point(24, 39);
            this.comboBox_ComPortsList.Name = "comboBox_ComPortsList";
            this.comboBox_ComPortsList.Size = new System.Drawing.Size(161, 21);
            this.comboBox_ComPortsList.Sorted = true;
            this.comboBox_ComPortsList.TabIndex = 2;
            this.comboBox_ComPortsList.DropDown += new System.EventHandler(this.comboBox_ComPortsList_DropDown);
            // 
            // label_ComPort
            // 
            this.label_ComPort.AutoSize = true;
            this.label_ComPort.Location = new System.Drawing.Point(21, 23);
            this.label_ComPort.Name = "label_ComPort";
            this.label_ComPort.Size = new System.Drawing.Size(53, 13);
            this.label_ComPort.TabIndex = 3;
            this.label_ComPort.Text = "Com Port:";
            // 
            // label_Tx
            // 
            this.label_Tx.AutoSize = true;
            this.label_Tx.Location = new System.Drawing.Point(21, 133);
            this.label_Tx.Name = "label_Tx";
            this.label_Tx.Size = new System.Drawing.Size(19, 13);
            this.label_Tx.TabIndex = 3;
            this.label_Tx.Text = "Tx";
            // 
            // label_Rx
            // 
            this.label_Rx.AutoSize = true;
            this.label_Rx.Location = new System.Drawing.Point(344, 23);
            this.label_Rx.Name = "label_Rx";
            this.label_Rx.Size = new System.Drawing.Size(20, 13);
            this.label_Rx.TabIndex = 3;
            this.label_Rx.Text = "Rx";
            // 
            // label_RxGrid
            // 
            this.label_RxGrid.AutoSize = true;
            this.label_RxGrid.Location = new System.Drawing.Point(344, 204);
            this.label_RxGrid.Name = "label_RxGrid";
            this.label_RxGrid.Size = new System.Drawing.Size(68, 13);
            this.label_RxGrid.TabIndex = 4;
            this.label_RxGrid.Text = "Rx Data Grid";
            // 
            // dataGridView_Rx
            // 
            this.dataGridView_Rx.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Rx.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MSG,
            this.length,
            this.isValid});
            this.dataGridView_Rx.Location = new System.Drawing.Point(347, 221);
            this.dataGridView_Rx.Name = "dataGridView_Rx";
            this.dataGridView_Rx.Size = new System.Drawing.Size(355, 217);
            this.dataGridView_Rx.TabIndex = 5;
            // 
            // MSG
            // 
            this.MSG.HeaderText = "MSG";
            this.MSG.Name = "MSG";
            this.MSG.ReadOnly = true;
            // 
            // length
            // 
            this.length.HeaderText = "length";
            this.length.Name = "length";
            this.length.ReadOnly = true;
            // 
            // isValid
            // 
            this.isValid.FalseValue = "0";
            this.isValid.HeaderText = "isValid";
            this.isValid.Name = "isValid";
            this.isValid.ReadOnly = true;
            this.isValid.TrueValue = "1023";
            // 
            // button_LED
            // 
            this.button_LED.Enabled = false;
            this.button_LED.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_LED.Location = new System.Drawing.Point(191, 93);
            this.button_LED.Name = "button_LED";
            this.button_LED.Size = new System.Drawing.Size(75, 23);
            this.button_LED.TabIndex = 6;
            this.button_LED.Text = "LED ON";
            this.button_LED.UseVisualStyleBackColor = true;
            this.button_LED.Click += new System.EventHandler(this.button_LED_Click);
            // 
            // textBox_Tx
            // 
            this.textBox_Tx.Location = new System.Drawing.Point(24, 149);
            this.textBox_Tx.Name = "textBox_Tx";
            this.textBox_Tx.Size = new System.Drawing.Size(161, 20);
            this.textBox_Tx.TabIndex = 1;
            // 
            // button_Exit
            // 
            this.button_Exit.Location = new System.Drawing.Point(627, 493);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(75, 23);
            this.button_Exit.TabIndex = 7;
            this.button_Exit.Text = "Exit";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel1.Location = new System.Drawing.Point(24, 221);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(242, 217);
            this.panel1.TabIndex = 8;
            // 
            // label_Transparent
            // 
            this.label_Transparent.AutoSize = true;
            this.label_Transparent.Location = new System.Drawing.Point(21, 204);
            this.label_Transparent.Name = "label_Transparent";
            this.label_Transparent.Size = new System.Drawing.Size(104, 13);
            this.label_Transparent.TabIndex = 9;
            this.label_Transparent.Text = "Transparent section:";
            // 
            // Timer
            // 
            this.Timer.Enabled = true;
            this.Timer.Interval = 1000;
            this.Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // label_Timer
            // 
            this.label_Timer.AutoSize = true;
            this.label_Timer.Location = new System.Drawing.Point(536, 459);
            this.label_Timer.Name = "label_Timer";
            this.label_Timer.Size = new System.Drawing.Size(36, 13);
            this.label_Timer.TabIndex = 11;
            this.label_Timer.Text = "Timer:";
            // 
            // numericUpDown_Number
            // 
            this.numericUpDown_Number.Location = new System.Drawing.Point(578, 459);
            this.numericUpDown_Number.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numericUpDown_Number.Name = "numericUpDown_Number";
            this.numericUpDown_Number.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Number.TabIndex = 12;
            this.numericUpDown_Number.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numericUpDown_Number.ValueChanged += new System.EventHandler(this.numericUpDown_Number_ValueChanged);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(721, 39);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(451, 477);
            this.webBrowser1.TabIndex = 13;
            this.webBrowser1.Url = new System.Uri("https://www.google.com", System.UriKind.Absolute);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(347, 492);
            this.progressBar.MarqueeAnimationSpeed = 50;
            this.progressBar.Name = "progressBar";
            this.progressBar.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.progressBar.RightToLeftLayout = true;
            this.progressBar.Size = new System.Drawing.Size(253, 23);
            this.progressBar.Step = 1;
            this.progressBar.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1216, 24);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thing1ToolStripMenuItem,
            this.thing2ToolStripMenuItem});
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.openToolStripMenuItem.Text = "Open Something";
            // 
            // thing1ToolStripMenuItem
            // 
            this.thing1ToolStripMenuItem.Name = "thing1ToolStripMenuItem";
            this.thing1ToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.thing1ToolStripMenuItem.Text = "Thing1";
            // 
            // thing2ToolStripMenuItem
            // 
            this.thing2ToolStripMenuItem.Name = "thing2ToolStripMenuItem";
            this.thing2ToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.thing2ToolStripMenuItem.Text = "Thing2";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pasteToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.pasteToolStripMenuItem.Text = "Do Something";
            // 
            // button_color
            // 
            this.button_color.Location = new System.Drawing.Point(347, 454);
            this.button_color.Name = "button_color";
            this.button_color.Size = new System.Drawing.Size(75, 23);
            this.button_color.TabIndex = 15;
            this.button_color.Text = "Pick a color";
            this.button_color.UseVisualStyleBackColor = true;
            this.button_color.Click += new System.EventHandler(this.button_color_Click);
            // 
            // comboBox_Screen
            // 
            this.comboBox_Screen.FormattingEnabled = true;
            this.comboBox_Screen.Location = new System.Drawing.Point(24, 493);
            this.comboBox_Screen.Name = "comboBox_Screen";
            this.comboBox_Screen.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Screen.TabIndex = 16;
            // 
            // label_Screen
            // 
            this.label_Screen.AutoSize = true;
            this.label_Screen.Location = new System.Drawing.Point(21, 477);
            this.label_Screen.Name = "label_Screen";
            this.label_Screen.Size = new System.Drawing.Size(74, 13);
            this.label_Screen.TabIndex = 17;
            this.label_Screen.Text = "Select Screen";
            // 
            // progressBarMarquee
            // 
            this.progressBarMarquee.Location = new System.Drawing.Point(347, 537);
            this.progressBarMarquee.Name = "progressBarMarquee";
            this.progressBarMarquee.Size = new System.Drawing.Size(253, 23);
            this.progressBarMarquee.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBarMarquee.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1216, 572);
            this.Controls.Add(this.progressBarMarquee);
            this.Controls.Add(this.label_Screen);
            this.Controls.Add(this.comboBox_Screen);
            this.Controls.Add(this.button_color);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.numericUpDown_Number);
            this.Controls.Add(this.label_Timer);
            this.Controls.Add(this.label_Transparent);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.button_LED);
            this.Controls.Add(this.dataGridView_Rx);
            this.Controls.Add(this.label_RxGrid);
            this.Controls.Add(this.label_Rx);
            this.Controls.Add(this.label_Tx);
            this.Controls.Add(this.label_ComPort);
            this.Controls.Add(this.comboBox_ComPortsList);
            this.Controls.Add(this.textBox_Rx);
            this.Controls.Add(this.textBox_Tx);
            this.Controls.Add(this.button_Connect);
            this.Controls.Add(this.button_Send);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Serial Test";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Rx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Number)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Send;
        private System.Windows.Forms.TextBox textBox_Rx;
        private System.Windows.Forms.Button button_Connect;
        private System.Windows.Forms.ComboBox comboBox_ComPortsList;
        private System.Windows.Forms.Label label_ComPort;
        private System.Windows.Forms.Label label_Tx;
        private System.Windows.Forms.Label label_Rx;
        private System.Windows.Forms.Label label_RxGrid;
        private System.Windows.Forms.DataGridView dataGridView_Rx;
        private System.Windows.Forms.DataGridViewTextBoxColumn MSG;
        private System.Windows.Forms.DataGridViewTextBoxColumn length;
        private System.Windows.Forms.DataGridViewCheckBoxColumn isValid;
        private System.Windows.Forms.Button button_LED;
        private System.Windows.Forms.TextBox textBox_Tx;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Transparent;
        private System.Windows.Forms.Timer Timer;
        private System.Windows.Forms.Label label_Timer;
        private System.Windows.Forms.NumericUpDown numericUpDown_Number;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thing1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thing2ToolStripMenuItem;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.Button button_color;
        private System.Windows.Forms.ComboBox comboBox_Screen;
        private System.Windows.Forms.Label label_Screen;
        private System.Windows.Forms.ProgressBar progressBarMarquee;
    }
}

